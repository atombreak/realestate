async function Info() {
    return `
    <div class="info" id="info">
                    <div class="contactInfo">
                        <div class="logo">
                            <img src="/images/LO.png" alt="">
                        </div>
                        <h2>Are you a property owner or an agent anywhere in Zambia? This is an ideal app to post real estate property for rent or sale because of a huge number of users. All1Zed real estate! Quick and Safe deals!</h2>
                        <a href="/auth/sign">
                            <h1>Register As An Agent!!!</h1>
                        </a>
                    </div>
                </div>
    `;
}